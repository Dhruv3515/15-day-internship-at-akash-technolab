<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'code' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'B-bil;0vcrOkJfq }2F%.)NbJ?x+99i}:{FU!Uc0[P>L(]xgacdJ{?bjT!@4$3U$' );
define( 'SECURE_AUTH_KEY',  ')DdJ (Z<w:m@MZDK]PfKXXdv{hfCv[1E{7*uNu{G!{tW4,m55UgO|pmv2Jn JM#!' );
define( 'LOGGED_IN_KEY',    'pY%tKR_5)] /Jid^nz7r76~%SjxeK^P~V-BmI6B^*-xol0_G+1MNIPOE-H!_UHwE' );
define( 'NONCE_KEY',        ']b9&ZRlra4rZ. _t)!|A^6&ID8i+l[XR+<%]bud>A*`p<2O.dJNW4*PUCk(%mXhP' );
define( 'AUTH_SALT',        'hRzBX6_}E_L~Y4Hb(O^4_@605>SfC7ZxP#;uMwRA)nbbp=f<KKjebeYF}rBfo,-q' );
define( 'SECURE_AUTH_SALT', 'u~/D#pA`x+Cmu7`x[{$(^AE^=@+a9|dtI ~hI ,@^!_Ase.:N1rZW`op|JVDx6<)' );
define( 'LOGGED_IN_SALT',   '?P%9M[%Jq_;v;&r0kZN@>.E{KKzq9H&lka/KHe{)V&@K|xu4Cve+rAZ$[pMGOcWa' );
define( 'NONCE_SALT',       'I X +<v_B~8T|n)@`|<o;J_99UdJ=u3G2E`Bj?FPo|DIf@96 D?m0`:jZS?3:5wD' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
